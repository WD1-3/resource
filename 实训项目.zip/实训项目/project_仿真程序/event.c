#include "event.h"
#include "UART.h"


static unsigned char btn_channel_size = 0;
extern btn_channel_t code btn_channel_map[];


void event_init(int len)
{
	btn_channel_size = len;
	UART_Init();
}

void event_update(void)
{
	int i;
	unsigned char command = 0xFF;
	
	if (UART_HasData())
	{
		command = UART_RecvByte();
	}
	
	if (0xFF == command)
	{
		return;
	}

	for (i = 0; i < btn_channel_size; i++)
	{
		if (btn_channel_map[i].command == command)
		{
			if (btn_channel_map[i].callback)
				btn_channel_map[i].callback();
			break;
		}
	}
}
