#ifndef __EVENT_H__
#define __EVENT_H__

#define EVENT_MAX 16

typedef void (*btn_callback_t)(void);
typedef struct 
{
	unsigned char command;
	btn_callback_t callback;
} btn_channel_t;

#define EVENT_REGISTER btn_channel_t code btn_channel_map[] = 
#define EVENT_INIT() event_init(sizeof(btn_channel_map) / sizeof(btn_channel_t))

void event_init(int len);
void event_update(void);



#endif //! __EVENT_H__
