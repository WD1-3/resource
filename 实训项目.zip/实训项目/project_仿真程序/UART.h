#ifndef __UART_H__
#define __UART_H__

#define UART_EVENT_0 '0'
#define UART_EVENT_1 '1'
#define UART_EVENT_2 '2'
#define UART_EVENT_3 '3'
#define UART_EVENT_4 '4'
#define UART_EVENT_5 '5'
#define UART_EVENT_6 '6'
#define UART_EVENT_7 '7'
#define UART_EVENT_8 '8'
#define UART_EVENT_9 '9'

#define UART_EVENT_CLEAR  'q'
#define UART_EVENT_UP 		'w'
#define UART_EVENT_DOWN 	's'
#define UART_EVENT_LEFT 	'a'
#define UART_EVENT_RIGHT  'd'
#define UART_EVENT_OK 		'o'
#define UART_EVENT_SHOW_CHANGE		'p'
#define UART_EVENT_TASK		't'

void UART_Init();
void UART_SendByte(unsigned char Byte);
char UART_HasData(void);
unsigned char UART_RecvByte(void);

#endif
