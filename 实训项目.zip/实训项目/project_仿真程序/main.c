#include <REGX52.H>
#include "Delay.h"
#include "MatrixLED.h"
#include "font.h"
#include "UART.h"
#include "event.h"

/**************************
 * 遥控器红外事件
 **************************/
#define IR_POWER		0x45
#define IR_MODE			0x46
#define IR_MUTE			0x47
#define IR_START_STOP	0x44
#define IR_PREVIOUS		0x40
#define IR_NEXT			0x43
#define IR_EQ			0x07
#define IR_VOL_MINUS	0x15
#define IR_VOL_ADD		0x09
#define IR_0			0x16
#define IR_RPT			0x19
#define IR_USD			0x0D
#define IR_1			0x0C
#define IR_2			0x18
#define IR_3			0x5E
#define IR_4			0x08
#define IR_5			0x1C
#define IR_6			0x5A
#define IR_7			0x42
#define IR_8			0x52
#define IR_9			0x4A

/* 光标坐标 */
static unsigned char x = 0, y = 0;

/**************************
 * 模式切换事件
 **************************/

void btn_event_change_mode(void)
{
	matrix_clear_image_plus(font_cur, x, y, 0, 0, 3, 3);
	x = 0;
	y = 0;
}

/**************************
 * 数字显示事件
 **************************/

void btn_event_0(void)
{
	matrix_clear();
	matrix_draw_image(font_0);
}

void btn_event_1(void)
{
	matrix_clear();
	matrix_draw_image(font_1);
}

void btn_event_2(void)
{
	matrix_clear();
	matrix_draw_image(font_2);
}

void btn_event_3(void)
{
	matrix_clear();
	matrix_draw_image(font_3);
}

void btn_event_4(void)
{
	matrix_clear();
	matrix_draw_image(font_4);
}

void btn_event_5(void)
{
	matrix_clear();
	matrix_draw_image(font_5);
}

void btn_event_6(void)
{
	matrix_clear();
	matrix_draw_image(font_6);
}

void btn_event_7(void)
{
	matrix_clear();
	matrix_draw_image(font_7);
}

void btn_event_8(void)
{
	matrix_clear();
	matrix_draw_image(font_8);
}

void btn_event_9(void)
{
	matrix_clear();
	matrix_draw_image(font_9);
}

void btn_event_clear(void)
{
	matrix_clear();
}

/**************************
 * 光标事件
 **************************/

static char is_draw = 0;

void cur_clear(void)
{
	matrix_clear_image_plus(font_cur, x, y, 0, 0, 3, 3);
	if (is_draw)
	{
		matrix_draw_point(x, y);
		is_draw = 0;
	}
}

void btn_event_up(void)
{
	cur_clear();
	if (y > 0)
		y--;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_down(void)
{
	cur_clear();
	if (y < 15)
		y++;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_left(void)
{
	cur_clear();
	if (x > 0)
		x--;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_right(void)
{
	cur_clear();
	if (x < 15)
		x++;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_ok(void)
{
	is_draw = 1;
}

static char s_is_show_hello_world = 0;
void btn_event_change_show_hello_world(void)
{
	s_is_show_hello_world = (!s_is_show_hello_world) ? 1 : 0;
	matrix_clear();
}
void repeate_show_hello_world(void)
{
	static const unsigned char *animation[] = {
		font_H,
		font_E,
		font_L,
		font_L,
		font_O,
		font_Exclamation};
	static int i = 0;
	int ms;
	if (0 == s_is_show_hello_world)
	{
			return;
	}
	matrix_clear();
	matrix_draw_image(animation[i]);
	i++;
	i %= 6;
	for (ms = 30; ms > 0; ms--)
	{
		matrix_fllush();
	}
	Delay(300);
}

EVENT_REGISTER{
	/**********************
	 *	测试用的事件
	 ***********************/
#if 0
	{UART_EVENT_0, btn_event_0},
	{UART_EVENT_1, btn_event_1},
	{UART_EVENT_2, btn_event_2},
	{UART_EVENT_3, btn_event_3},
	{UART_EVENT_4, btn_event_4},
	{UART_EVENT_5, btn_event_5},
	{UART_EVENT_6, btn_event_6},
	{UART_EVENT_7, btn_event_7},
	{UART_EVENT_8, btn_event_8},
	{UART_EVENT_9, btn_event_9},
	{UART_EVENT_CLEAR, btn_event_clear},
	{UART_EVENT_UP 	, btn_event_up},
	{UART_EVENT_DOWN , btn_event_down},
	{UART_EVENT_LEFT , btn_event_left},
	{UART_EVENT_RIGHT, btn_event_right},
	{UART_EVENT_OK 	, btn_event_ok},
	{UART_EVENT_SHOW_CHANGE, btn_event_change_show_hello_world},
#endif
	
	/**********************
	 *	红外遥控器事件
	 ***********************/
	{IR_0, btn_event_0},
	{IR_1, btn_event_1},
	{IR_2, btn_event_2},
	{IR_3, btn_event_3},
	{IR_4, btn_event_4},
	{IR_5, btn_event_5},
	{IR_6, btn_event_6},
	{IR_7, btn_event_7},
	{IR_8, btn_event_8},
	{IR_9, btn_event_9},
	{IR_POWER, btn_event_clear},
	{IR_MODE, btn_event_up},
	{IR_VOL_MINUS, btn_event_down},
	{IR_START_STOP, btn_event_left},
	{IR_NEXT, btn_event_right},
	{IR_PREVIOUS, btn_event_ok},
	{IR_USD, btn_event_change_show_hello_world},
	{IR_VOL_ADD, btn_event_change_mode}
};

/**************************
 * 主程序
 **************************/
void main()
{
	unsigned char recv_data = 0;
	EVENT_INIT();
	matrix_clear();
	while (1)
	{
		event_update();
		repeate_show_hello_world();
		matrix_fllush();
	}
}
