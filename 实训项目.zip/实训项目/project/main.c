#include <REGX52.H>
#include "Delay.h"
#include "MatrixLED.h"
#include "font.h"
#include "IR.h"
#include "key.h"
#include "event.h"

/* 光标坐标 */
static unsigned char x = 0, y = 0;

/**************************
 * 模式切换事件
 **************************/

enum {
	EVENT_MODE0 = 0, /* 同步显示 */
	EVENT_MODE1,		 /* 只显示真实单片机 */
	EVENT_MODE2,		 /* 只显示仿真单片机 */
	EVENT_END
} EVENT_MODE = EVENT_MODE0;

#define MODE_EVENT_RESET 0x8F

/* 同步显示 */
static void event_mode0(void)
{
	btn_event_send_uart_open();
	btn_event_open();
}

/* 只显示真实单片机 */
static void event_mode1(void)
{
	btn_event_send_uart_close();
	btn_event_open();
}

 /* 只显示仿真单片机 */
static void event_mode2(void)
{
	btn_event_send_uart_open();
	btn_event_close();
}

void btn_event_change_mode(void)
{
	(int)EVENT_MODE++;
	EVENT_MODE %= EVENT_END;
	switch(EVENT_MODE)
	{
		case EVENT_MODE0:
			event_mode0();
		break;
	 case EVENT_MODE1:
			event_mode1();
		break;
	 case EVENT_MODE2:
			event_mode2();
		break;
	}
	matrix_clear_image_plus(font_cur, x, y, 0, 0, 3, 3);
	x = 0;
	y = 0;
}

/**************************
 * 数字显示事件
 **************************/
 
void btn_event_0(void)
{
	matrix_clear();
	matrix_draw_image(font_0);
}

void btn_event_1(void)
{
	matrix_clear();
	matrix_draw_image(font_1);
}

void btn_event_2(void)
{
	matrix_clear();
	matrix_draw_image(font_2);
}

void btn_event_3(void)
{
	matrix_clear();
	matrix_draw_image(font_3);
}

void btn_event_4(void)
{
	matrix_clear();
	matrix_draw_image(font_4);
}

void btn_event_5(void)
{
	matrix_clear();
	matrix_draw_image(font_5);
}

void btn_event_6(void)
{
	matrix_clear();
	matrix_draw_image(font_6);
}

void btn_event_7(void)
{
	matrix_clear();
	matrix_draw_image(font_7);
}

void btn_event_8(void)
{
	matrix_clear();
	matrix_draw_image(font_8);
}

void btn_event_9(void)
{
	matrix_clear();
	matrix_draw_image(font_9);
}

void btn_event_clear(void)
{
	matrix_clear();
}

/**************************
 * 光标事件
 **************************/
static char is_draw = 0;

void cur_clear(void)
{
	matrix_clear_image_plus(font_cur, x, y, 0, 0, 3, 3);
	if (is_draw)
	{
		matrix_draw_point(x, y);
		is_draw = 0;
	}
}

void btn_event_up(void)
{
	cur_clear();
	if (y > 0)
		y--;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_down(void)
{
	cur_clear();
	if (y < 15)
		y++;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_left(void)
{
	cur_clear();
	if (x > 0)
		x--;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_right(void)
{
	cur_clear();
	if (x < 15)
		x++;
	// matrix_draw_point(x, y);
	matrix_draw_image_plus(font_cur, x, y, 0, 0, 3, 3);
}

void btn_event_ok(void)
{
	is_draw = 1;
}

static char s_is_show_hello_world = 0;
void btn_event_change_show_hello_world(void)
{
	s_is_show_hello_world = (!s_is_show_hello_world) ? 1 : 0;
	matrix_clear();
}
void repeate_show_hello_world(void)
{
	static const unsigned char *animation[] = {
		font_H,
		font_E,
		font_L,
		font_L,
		font_O,
		font_Exclamation};
	static int i = 0;
	int ms;
	if (0 == s_is_show_hello_world)
	{
			return;
	}
	matrix_clear();
	matrix_draw_image(animation[i]);
	i++;
	i %= 6;
	for (ms = 30; ms > 0; ms--)
	{
		matrix_fllush();
	}
	Delay(300);
}

/**************************
 * 计划任务
 * 目前打算简单点, 大概就
 * 是特地时间显示hello.
 **************************/
static char s_open_task_flag = 0;
static unsigned int s_now_time = 0;
void btn_event_task(void)
{
	s_open_task_flag = 1;
	s_now_time = Timer_GetSecond();
}

void event_task_update(void)
{
	if (s_open_task_flag && Timer_GetSecond() - s_now_time >= 10)
	{
		s_is_show_hello_world = 1;
		s_open_task_flag = 0;
	}
}

EVENT_REGISTER{
	/**********************
	 *	红外遥控器事件
	 ***********************/
	{IR_0, btn_event_0},
	{IR_1, btn_event_1},
	{IR_2, btn_event_2},
	{IR_3, btn_event_3},
	{IR_4, btn_event_4},
	{IR_5, btn_event_5},
	{IR_6, btn_event_6},
	{IR_7, btn_event_7},
	{IR_8, btn_event_8},
	{IR_9, btn_event_9},
	{IR_POWER, btn_event_clear},
	{IR_MODE, btn_event_up},
	{IR_VOL_MINUS, btn_event_down},
	{IR_START_STOP, btn_event_left},
	{IR_NEXT, btn_event_right},
	{IR_PREVIOUS, btn_event_ok},
	{IR_USD, btn_event_change_show_hello_world},
	{IR_EQ, btn_event_task},

	/**********************
	 *	矩阵按钮事件
	 ***********************/
	{KEY_VALUE_0, btn_event_0},
	{KEY_VALUE_1, btn_event_1},
	{KEY_VALUE_2, btn_event_2},
	{KEY_VALUE_3, btn_event_3},
	{KEY_VALUE_4, btn_event_4},
	{KEY_VALUE_5, btn_event_5},
	{KEY_VALUE_6, btn_event_6},
	{KEY_VALUE_7, btn_event_7},
	{KEY_VALUE_8, btn_event_8},
	{KEY_VALUE_9, btn_event_9},

	{KEY_VALUE_10, btn_event_up},
	{KEY_VALUE_11, btn_event_ok},
	{KEY_VALUE_12, btn_event_clear},
	{KEY_VALUE_13, btn_event_left},
	{KEY_VALUE_14, btn_event_down},
	{KEY_VALUE_15, btn_event_right}};

/**************************
 * 主程序
 **************************/
void main()
{
	/* 设备, 事件初始化. */
	btn_channel_t bc = { IR_VOL_ADD, btn_event_change_mode };
	EVENT_INIT();
	btn_event_set_before_callback(&bc); /* 模式切换不能屏蔽 */
	event_mode0(); /* 默认模式0 */
	
	IR_Init();
	Timer0_Init();
	matrix_clear();
	while (1)
	{
		btn_event_update();
		event_task_update();
		repeate_show_hello_world();
		matrix_fllush();
	}
}

