#include <REGX52.H>
#include "MatrixLED.h"

//--定义SPI要使用的 IO--//
sbit MOSIO = P3 ^ 4;
sbit R_CLK = P3 ^ 5;
sbit S_CLK = P3 ^ 6;

//--点阵显示数组--//
static uchar code tab0[] =
	{0x00, 0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08,
	 0x00, 0x10, 0x00, 0x20, 0x00, 0x40, 0x00, 0x80,
	 0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08, 0x00,
	 0x10, 0x00, 0x20, 0x00, 0x40, 0x00, 0x80, 0x00};

//--缓冲区--//
static uchar s_image_buf[32];

/*******************************************************************************
 * 函 数 名         : HC595SendData
 * 函数功能		     : 通过595发送四个字节的数据
 * 输    入         : BT3：第四个595输出数值
 *                  * BT2: 第三个595输出数值
 *                  * BT1：第二个595输出数值
 *                  * BT0：第一个595输出数值
 * 输    出         : 无
 *******************************************************************************/
static void HC595SendData(uchar BT3, uchar BT2, uchar BT1, uchar BT0)
{
	uchar i;

	//--发送第一个字节--//
	for (i = 0; i < 8; i++)
	{
		MOSIO = BT3 >> 7; // 从高位到低位
		BT3 <<= 1;

		S_CLK = 0;
		S_CLK = 1;
	}

	//--发送第一个字节--//
	for (i = 0; i < 8; i++)
	{
		MOSIO = BT2 >> 7; // 从高位到低位
		BT2 <<= 1;

		S_CLK = 0;
		S_CLK = 1;
	}

	//--发送第一个字节--//
	for (i = 0; i < 8; i++)
	{
		MOSIO = BT1 >> 7; // 从高位到低位
		BT1 <<= 1;
		S_CLK = 0;
		S_CLK = 1;
	}

	//--发送第一个字节--//
	for (i = 0; i < 8; i++)
	{
		MOSIO = BT0 >> 7; // 从高位到低位
		BT0 <<= 1;
		S_CLK = 0;
		S_CLK = 1;
	}

	//--输出--//
	R_CLK = 0; // set dataline low
	R_CLK = 1; // 片选
	R_CLK = 0; // set dataline low
}

/*******************************************************************************
 * 函 数 名         : matrix_draw_image
 * 函数功能		     : 绘制字摸图像, 可以用软件画, 需要调用 matrix_fllush 显示
 * 输    入         : image：字摸图像
 * 输    出         : 无
 *******************************************************************************/
void matrix_draw_image(uchar *image)
{
	int i;
	for (i = 0; i < 32; ++i)
	{
		s_image_buf[i] |= image[i];
	}
}

void matrix_draw_image_plus(uchar *image, unsigned short win_x, unsigned short win_y, unsigned short x, unsigned short y, unsigned short w, unsigned short h)
{
	unsigned short i, j;
	if (x >= 16 || y >= 16 || win_x >= 16 || win_y >= 16 || w == 0 || h == 0)
		return;

	for (i = x; i <= w + x - 1; i++)
	{
		for (j = y; j < h + y; j++)
		{
				if (matrix_get_image_point(image, i, j))
				{
					matrix_draw_point(win_x + i - x, win_y + j - y);
				}
		}		
	}
}

void matrix_clear_image_plus(uchar *image, unsigned short win_x, unsigned short win_y, unsigned short x, unsigned short y, unsigned short w, unsigned short h)
{
	unsigned short i, j;
	if (x >= 16 || y >= 16 || win_x >= 16 || win_y >= 16 || w == 0 || h == 0)
		return;

	for (i = x; i <= w + x - 1; i++)
	{
		for (j = y; j < h + y; j++)
		{
				if (matrix_get_image_point(image, i, j))
				{
					matrix_clear_point(win_x + i - x, win_y + j - y);
				}
		}		
	}
}



/*******************************************************************************
 * 函 数 名         : matrix_draw_point
 * 函数功能		     : 根据 x, y 点亮对于坐标的led, 需要调用 matrix_fllush 显示
 * 输    入         : x：x坐标
 *                  * y: y坐标
 * 输    出         : 无
 *******************************************************************************/
void matrix_draw_point(unsigned short x, unsigned short y)
{
	if (x >= 16 || y >= 16)
		return;
	*(s_image_buf + (y * 16 + x) / 8) |= (1 << x % 8);
}

/*******************************************************************************
 * 函 数 名         : matrix_get_image_point
 * 函数功能		      : 根据 x, y 获得image对应的坐标led, 需要调用 matrix_fllush 显示
 * 输    入         : image：image
 * 									: x：x坐标
 *                  * y: y坐标
 * 输    出         : 1 亮 0 灭
 *******************************************************************************/
uchar matrix_get_image_point(uchar *image, unsigned short x, unsigned short y)
{
	if (x >= 16 || y >= 16)
		return 0;
	return (*(image + (y * 16 + x) / 8) >> (x % 8)) & 1;
}

/*******************************************************************************
 * 函 数 名         : matrix_clear_point
 * 函数功能		     : 根据 x, y 点灭对于坐标的led情况
 * 输    入         : x：x坐标
 *                  * y: y坐标
 * 输    出         : 无
 *******************************************************************************/
void matrix_clear_point(unsigned short x, unsigned short y)
{
	if (x >= 16 || y >= 16)
		return;
	*(s_image_buf + (y * 16 + x) / 8) &= (~(1 << x % 8));
}

/*******************************************************************************
 * 函 数 名         : matrix_clear
 * 函数功能		     : 清空缓冲区
 * 输    入         : 无
 * 输    出         : 无
 *******************************************************************************/
void matrix_clear(void)
{
	int i;
	for (i = 0; i < 32; ++i)
	{
		s_image_buf[i] = 0;
	}
}

/*******************************************************************************
 * 函 数 名         : matrix_fllush
 * 函数功能		     : 刷新缓冲区到显示
 * 输    入         : 无
 * 输    出         : 无
 *******************************************************************************/
void matrix_fllush(void)
{
	int k;
	for (k = 0; k < 16; k++)
	{
		HC595SendData(~s_image_buf[2 * k + 1], ~s_image_buf[2 * k], tab0[2 * k], tab0[2 * k + 1]);
	}
	HC595SendData(0xff, 0xff, 0, 0);
}
