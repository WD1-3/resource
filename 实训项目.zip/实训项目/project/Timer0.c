#include <REGX52.H>

static unsigned long s_second = 0;

/**
  * @brief  定时器1初始化
  * @param  无
  * @retval 无
  */
void Timer0_Init(void)
{
	TMOD &= 0xF0; // 设置定时器模式
	TMOD |= 0x01; // 设置定时器模式

	TL0 = 0xb0; // 低8位
	TH0 = 0x3c; // 高8位
	TF0 = 0;
	TR0 = 1;
	ET0 = 1; 
	EA = 1;	
}


/**
  * @brief  获得当前运行时间，单位s
  * @param  无
  * @retval 无
  */
unsigned long Timer_GetSecond(void)
{
	return s_second;
}

void T0_timer() interrupt 1
{
	static unsigned int ind = 0;
	TL0 = 0xb0; // 低8位
	TH0 = 0x3c; // 高8位
	ind++;
	if (ind >= 20) // 1s 触发一次
	{
		s_second++;
		ind = 0;
	}
}


