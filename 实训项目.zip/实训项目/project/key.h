#ifndef __KEY_H__
#define __KEY_H__

#define KEY_NOT_DOWN 0xFF

#define KEY_VALUE_0 (0 | 0x80)
#define KEY_VALUE_1 (1 | 0x80)
#define KEY_VALUE_2 (2 | 0x80)
#define KEY_VALUE_3 (3 | 0x80)
#define KEY_VALUE_4 (4 | 0x80)
#define KEY_VALUE_5 (5 | 0x80)
#define KEY_VALUE_6 (6 | 0x80)
#define KEY_VALUE_7 (7 | 0x80)
#define KEY_VALUE_8 (8 | 0x80)
#define KEY_VALUE_9 (9 | 0x80)
#define KEY_VALUE_10 (10 | 0x80)
#define KEY_VALUE_11 (11 | 0x80)
#define KEY_VALUE_12 (12 | 0x80)
#define KEY_VALUE_13 (13 | 0x80)
#define KEY_VALUE_14 (14 | 0x80)
#define KEY_VALUE_15 (15 | 0x80)

void KeyUpdate(void);
unsigned char getKeyValue(void);

#endif // !__KEY_H__
