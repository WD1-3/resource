#include <REGX52.H>

typedef unsigned int u16; // 对数据类型进行声明定义
typedef unsigned char u8;

sbit IRIN = P3 ^ 2;
u8 IrValue[6];
u8 Time;
unsigned char IR_DataFlag = 0;
unsigned char IR_Data = 0xFF;

/*******************************************************************************
 * 函 数 名         : delay
 * 函数功能		   : 延时函数，i=1时，大约延时10us
 *******************************************************************************/
static void delay(u16 i)
{
	while (i--)
		;
}

/**
 * @brief  红外遥控初始化
 * @param  无
 * @retval 无
 */
void IR_Init(void)
{
	IT0 = 1;  // 下降沿触发
	EX0 = 1;  // 打开中断0允许
	EA = 1;	  // 打开总中断
	IRIN = 1; // 初始化端口
}

/**
 * @brief  红外遥控获取收到数据帧标志位
 * @param  无
 * @retval 是否收到数据帧，1为收到，0为未收到
 */
unsigned char IR_GetDataFlag(void)
{
	if (IR_DataFlag)
	{
		IR_DataFlag = 0;
		return 1;
	}
	return 0;
}

/**
 * @brief  红外遥控获取收到的命令数据
 * @param  无
 * @retval 收到的命令数据
 */
unsigned char IR_GetCommand(void)
{
	unsigned char ret = IR_Data;
	IR_Data = 0xFF;
	return ret;
}

/*******************************************************************************
 * 函数名         : ReadIr()
 * 函数功能		   : 读取红外数值的中断函数
 * 输入           : 无
 * 输出         	 : 无
 *******************************************************************************/
void ReadIr() interrupt 0
{
	u8 j, k;
	u16 err;
	Time = 0;
	delay(700);	   // 7ms
	if (IRIN == 0) // 确认是否真的接收到正确的信号
	{

		err = 1000; // 1000*10us=10ms,超过说明接收到错误的信号
		/*当两个条件都为真是循环，如果有一个条件为假的时候跳出循环，免得程序出错的时
		侯，程序死在这里*/
		while ((IRIN == 0) && (err > 0)) // 等待前面9ms的低电平过去
		{
			delay(1);
			err--;
		}
		if (IRIN == 1) // 如果正确等到9ms低电平
		{
			err = 500;
			while ((IRIN == 1) && (err > 0)) // 等待4.5ms的起始高电平过去
			{
				delay(1);
				err--;
			}
			for (k = 0; k < 4; k++) // 共有4组数据
			{
				for (j = 0; j < 8; j++) // 接收一组数据
				{

					err = 60;
					while ((IRIN == 0) && (err > 0)) // 等待信号前面的560us低电平过去
					{
						delay(1);
						err--;
					}
					err = 500;
					while ((IRIN == 1) && (err > 0)) // 计算高电平的时间长度。
					{
						delay(10); // 0.1ms
						Time++;
						err--;
						if (Time > 30)
						{
							return;
						}
					}
					IrValue[k] >>= 1; // k表示第几组数据
					if (Time >= 8)	  // 如果高电平出现大于565us，那么是1
					{
						IrValue[k] |= 0x80;
					}
					Time = 0; // 用完时间要重新赋值
				}
			}
		}
		if (IrValue[2] != ~IrValue[3])
		{
			return;
		}
		IR_Data = IrValue[2];
		IR_DataFlag = 1;
	}
}
