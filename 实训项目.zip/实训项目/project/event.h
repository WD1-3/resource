#ifndef __EVENT_H__
#define __EVENT_H__

#define EVENT_MAX 16

typedef void (*btn_callback_t)(void);
typedef struct 
{
	unsigned char command;
	btn_callback_t callback;
} btn_channel_t;

#define EVENT_REGISTER btn_channel_t code btn_channel_map[] = 
#define EVENT_INIT() btn_event_init(sizeof(btn_channel_map) / sizeof(btn_channel_t))

void btn_event_init(int len);
void btn_event_update(void);
void btn_event_send_uart_open(void);
void btn_event_send_uart_close(void);
void btn_event_open(void);
void btn_event_close(void);
void btn_event_set_before_callback(btn_channel_t* pbc);

#endif //! __EVENT_H__
