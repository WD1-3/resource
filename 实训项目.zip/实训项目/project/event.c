#include "event.h"
#include "key.h"
#include "UART.h"

static unsigned char btn_channel_size = 0;
extern btn_channel_t code btn_channel_map[];
static char s_uart_send_flag = 0;
static char s_event_enable_flag = 0;
static btn_channel_t* s_pbc;

// �����ڴ治��, ����ȡ�˷���.
// static btn_channel_t s_btn_channel[EVENT_MAX];
// void btn_event_register(unsigned char command, btn_callback_t _callback)
//{
//	if (btn_channel_size > EVENT_MAX)
//		return;
//	s_btn_channel[btn_channel_size].command = command;
//	s_btn_channel[btn_channel_size].callback = _callback;
//	btn_channel_size++;
//}

void btn_event_init(int len)
{
	btn_channel_size = len;
	s_pbc = 0;
	UART_Init();
}

void btn_event_send_uart_open(void)
{
	s_uart_send_flag = 1;
}

void btn_event_send_uart_close(void)
{
	s_uart_send_flag = 0;
}

void btn_event_open(void)
{
	s_event_enable_flag = 1;
}

void btn_event_close(void)
{
	s_event_enable_flag = 0;
}

void btn_event_set_before_callback(btn_channel_t* pbc)
{
	s_pbc = pbc;
}

void btn_event_update(void)
{
	int i;
	unsigned char command = 0xFF;
	unsigned char key_value = KEY_NOT_DOWN;

	if (IR_GetDataFlag())
	{
		command = IR_GetCommand();
	}

	KeyUpdate();
	key_value = getKeyValue();
	if (KEY_NOT_DOWN != key_value)
	{
		command = key_value;
	}

	if (0xFF == command)
	{
		return;
	}
	
	if (s_uart_send_flag)
		UART_SendByte(command); // �������뷢�͵�����ƽ̨��ȥ.
	
	if (s_pbc && s_pbc->command == command)
	{
		if (s_pbc->callback)
				s_pbc->callback();
		return;
	}
	
	if (!s_event_enable_flag)
		return;
	
	for (i = 0; i < btn_channel_size; i++)
	{
		if (btn_channel_map[i].command == command)
		{
			if (btn_channel_map[i].callback)
				btn_channel_map[i].callback();
			break;
		}
	}
}

