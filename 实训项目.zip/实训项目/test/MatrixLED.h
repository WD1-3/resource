#ifndef __MATRIX_LED_H__
#define __MATRIX_LED_H__

//--�ض��庯������--//
#define uchar unsigned char
#define uint  unsigned int
#define ulong unsigned long

void matrix_draw_image(uchar* image);
void matrix_draw_image_plus(uchar *image, unsigned short win_x, unsigned short win_y, unsigned short x, unsigned short y, unsigned short w, unsigned short h);
void matrix_draw_point(unsigned short x, unsigned short y);
uchar matrix_get_image_point(uchar *image, unsigned short x, unsigned short y);
void matrix_clear_point(unsigned short x, unsigned short y);
void  matrix_clear(void);
void matrix_fllush(void);

#endif
